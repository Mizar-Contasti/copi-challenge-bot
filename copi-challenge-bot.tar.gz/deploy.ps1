# Deploy Copi Challenge Bot to Google Cloud Run
# PowerShell deployment script with updated URLs

Write-Host "Deploying Copi Challenge Bot to Google Cloud Run..." -ForegroundColor Green

# Deploy command with proper PowerShell formatting and all environment variables
gcloud run deploy copi-challenge-bot `
  --source . `
  --region us-central1 `
  --allow-unauthenticated `
  --port 8000 `
  --memory 1Gi `
  --cpu 1 `
  --max-instances 10 `
  --set-env-vars "ENVIRONMENT=production,OPENAI_API_KEY=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,BASE_URL=https://copi-challenge-bot-272897586446.us-central1.run.app,API_BASE_URL=https://copi-challenge-bot-272897586446.us-central1.run.app,SWAGGER_DOCS_URL=https://copi-challenge-bot-272897586446.us-central1.run.app/docs"

if ($LASTEXITCODE -eq 0) {
    Write-Host "Deployment successful!" -ForegroundColor Green
    Write-Host "Your API is now available at: https://copi-challenge-bot-272897586446.us-central1.run.app" -ForegroundColor Cyan
    Write-Host "API Documentation: https://copi-challenge-bot-272897586446.us-central1.run.app/docs" -ForegroundColor Cyan
} else {
    Write-Host "Deployment failed. Check the error messages above." -ForegroundColor Red
}
