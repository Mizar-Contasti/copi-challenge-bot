#!/bin/bash
# Deploy Copi Challenge Bot to Google Cloud Run
# Bash deployment script for Linux/Mac

echo "Deploying Copi Challenge Bot to Google Cloud Run..."

gcloud run deploy copi-challenge-bot \
  --source . \
  --region us-central1 \
  --allow-unauthenticated \
  --port 8000 \
  --memory 1Gi \
  --cpu 1 \
  --max-instances 10 \
  --set-env-vars "ENVIRONMENT=production,OPENAI_API_KEY=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"

if [ $? -eq 0 ]; then
    echo "Deployment successful!"
    echo "Your API is now available at the URL shown above."
else
    echo "Deployment failed. Check the error messages above."
fi
