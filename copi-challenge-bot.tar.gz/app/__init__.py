"""
Debate Bot Application Package
A conversational AI that maintains controversial positions in debates.
"""

__version__ = "1.0.0"