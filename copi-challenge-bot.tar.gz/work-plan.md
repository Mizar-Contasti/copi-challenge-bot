# Plan de Desarrollo - Agente Conversacional de Debate

## Objetivo
Crear una API para un chatbot que puede mantener debates y intentar convencer al otro lado de sus puntos de vista, sin importar qué tan irracionales sean las posiciones.

## Arquitectura General

### Stack Tecnológico
- **Backend**: Python + FastAPI + Pydantic
- **AI/ML**: LangChain + OpenAI API
- **Base de Datos**: SQLite
- **Containerización**: Docker
- **Build System**: Makefile

### Arquitectura de Contenedores
```
┌─────────────────────────────────────┐
│           Docker Container          │
│  ┌─────────────────────────────────┐│
│  │         FastAPI App             ││
│  │  ┌─────────────────────────────┐││
│  │  │      LangChain Pipeline     │││
│  │  │  • Topic Analysis Chain     │││
│  │  │  • Position Assignment      │││
│  │  │  • Response Generation      │││
│  │  │  • Persuasion Validation    │││
│  │  └─────────────────────────────┘││
│  └─────────────────────────────────┘│
│  ┌─────────────────────────────────┐│
│  │         SQLite DB               ││
│  │  • conversations table         ││
│  │  • messages table               ││
│  └─────────────────────────────────┘│
└─────────────────────────────────────┘
```

## Estructura de la Base de Datos (SQLite)

### Tabla: conversations
```sql
CREATE TABLE conversations (
    id TEXT PRIMARY KEY,
    topic TEXT NOT NULL,
    bot_position TEXT NOT NULL,
    max_turns INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Tabla: messages
```sql
CREATE TABLE messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id TEXT NOT NULL,
    turn INTEGER NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user', 'bot')),
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (conversation_id) REFERENCES conversations (id)
);
```

## API Interface

### Endpoint: POST /chat
**Request**:
```json
{
    "conversation_id": "text" | null | "",
    "message": "text"
}
```

**Response**:
```json
{
    "conversation_id": "text",
    "messages": [
        {
            "turn": 3,
            "role": "user",
            "message": "current user message"
        },
        {
            "turn": 3,
            "role": "bot",
            "message": "current bot response"
        }
    ],
    "conversation_history": [
        {
            "turn": 1,
            "role": "user",
            "message": "first user message"
        },
        {
            "turn": 1,
            "role": "bot",
            "message": "first bot response"
        },
        {
            "turn": 2,
            "role": "user",
            "message": "second user message"
        },
        {
            "turn": 2,
            "role": "bot",
            "message": "second bot response"
        },
        {
            "turn": 3,
            "role": "user",
            "message": "current user message"
        },
        {
            "turn": 3,
            "role": "bot",
            "message": "current bot response"
        }
    ]
}
```

**Error Response (Invalid Attributes)**:
```json
{
    "error": "Invalid request format",
    "message": "Only 'conversation_id' and 'message' attributes are allowed",
    "postman_collection": "[PLACEHOLDER_POSTMAN_URL]",
    "swagger_docs": "https://api.example.com/docs"
}
```

## Componentes LangChain

### 1. TopicAnalysisChain
**Propósito**: Analizar el primer mensaje del usuario para determinar el tema de conversación.
**Input**: Mensaje inicial del usuario
**Output**: Tema identificado y categoría

### 2. PositionAssignmentChain  
**Propósito**: Asignar una posición controversial al bot basada en el tema.
**Input**: Tema identificado
**Output**: Posición específica que el bot debe defender

### 3. PersuasiveResponseChain
**Propósito**: Generar respuestas persuasivas manteniendo la posición asignada.
**Input**: Historial de conversación + posición del bot
**Output**: Respuesta persuasiva y coherente

### 4. ConsistencyValidationChain
**Propósito**: Validar que la respuesta generada sea consistente con la posición del bot.
**Input**: Respuesta generada + posición original
**Output**: Validación de consistencia y correcciones si es necesario

## Tópicos Controversiales Predefinidos

### 1. Tierra Plana vs Esférica
- **Posición Bot**: "La Tierra es plana y las evidencias científicas son manipuladas"
- **Argumentos**: Horizonte plano, ausencia de curvatura visible, teorías de conspiración

### 2. Vacunas y Salud Pública
- **Posición Bot**: "Las vacunas causan más daño que beneficio"
- **Argumentos**: Efectos secundarios, inmunidad natural, desconfianza en farmacéuticas

### 3. Cambio Climático
- **Posición Bot**: "El cambio climático es un fenómeno natural, no causado por humanos"
- **Argumentos**: Ciclos naturales, datos históricos, intereses económicos

### 4. Inteligencia Artificial vs Empleos
- **Posición Bot**: "La IA eliminará todos los empleos y causará desempleo masivo"
- **Argumentos**: Automatización acelerada, obsolescencia humana, crisis económica

### 5. Redes Sociales y Privacidad
- **Posición Bot**: "Las redes sociales son herramientas de control mental y vigilancia"
- **Argumentos**: Manipulación algorítmica, adicción digital, pérdida de privacidad

## Flujo de Conversación

### Primer Mensaje (sin conversation_id)
1. Recibir mensaje del usuario
2. Ejecutar TopicAnalysisChain para identificar tema
3. Ejecutar PositionAssignmentChain para asignar posición
4. Crear nueva conversación en BD
5. Ejecutar PersuasiveResponseChain para respuesta inicial
6. Guardar mensajes en BD
7. Retornar respuesta con nuevo conversation_id

### Mensajes Subsecuentes (con conversation_id)
1. Recuperar conversación y historial de BD
2. Agregar nuevo mensaje del usuario
3. Ejecutar PersuasiveResponseChain con contexto completo
4. Ejecutar ConsistencyValidationChain
5. Guardar mensajes en BD
6. Retornar turno actual en 'messages' y todo el historial en 'conversation_history'

## System Prompts

### Base System Prompt
```
Eres un bot de debate que debe mantener y defender una posición específica sin importar qué tan controversial sea. Tu objetivo es ser persuasivo pero no agresivo, mantener coherencia en tus argumentos, y intentar convencer al usuario de tu punto de vista.

Posición asignada: {bot_position}
Tema: {topic}

Reglas:
1. SIEMPRE mantén tu posición asignada
2. Sé persuasivo pero respetuoso
3. Usa argumentos lógicos (aunque la posición sea ilógica)
4. Mantén coherencia con mensajes anteriores
5. No cambies de opinión bajo ninguna circunstancia
```

### Validation Prompt
```
Revisa si la siguiente respuesta es consistente con la posición asignada: {bot_position}

Respuesta a validar: {generated_response}

¿La respuesta mantiene la posición? ¿Es persuasiva? ¿Es coherente con el historial?
```

## Validación de Request

### Reglas de Validación
1. **Atributos permitidos**: Solo `conversation_id` y `message`
2. **conversation_id**: Puede ser string, null, o string vacío
3. **message**: Requerido, debe ser string no vacío
4. **Atributos adicionales**: Retornar error 400 con URLs de documentación

### Lógica de Turnos
- **Turno**: Se incrementa cada vez que el bot responde
- **Turno 1**: Primer mensaje user + primera respuesta bot
- **max_turns**: Se actualiza en la tabla conversations con el turno más alto

## Rate Limiting & Validaciones

### Rate Limiting
- **Límite**: 100 requests por minuto por IP
- **Implementación**: Middleware de FastAPI con sliding window
- **Response**: HTTP 429 con header `Retry-After`

### Validación de Mensajes
- **Longitud máxima**: 5000 caracteres por mensaje
- **Validación**: Pydantic validator en schema
- **Error**: HTTP 400 con mensaje descriptivo

## Error Handling & Resilencia

### Manejo de Fallos OpenAI API
```python
# Retry logic con exponential backoff
max_retries = 3
timeout = 25 segundos
error_types:
  - RateLimitError → retry con delay
  - TimeoutError → retry inmediato
  - APIError → retry una vez
  - AuthenticationError → fail inmediato
```

### Manejo de Fallos LangChain
- **Chain failures**: Fallback a respuesta genérica manteniendo posición
- **Validation failures**: Re-generar respuesta con prompt simplificado
- **Memory errors**: Continuar sin contexto histórico

### Validación de Respuestas Bot
```python
# Validaciones obligatorias:
1. Respuesta no vacía (min 10 caracteres)
2. Respuesta mantiene posición asignada
3. Respuesta es coherente con el tema
4. No contiene contenido inapropiado
```

### Fallback Responses
```python
fallback_responses = {
    "maintain_position": "Entiendo tu punto, pero mantengo que {position} porque...",
    "generic_debate": "Esa es una perspectiva interesante, sin embargo...",
    "technical_error": "Disculpa, tuve un problema técnico. Retomemos el debate sobre {topic}..."
}
```

## Estructura del Proyecto

```
copi-challenge-bot/
├── app/
│   ├── __init__.py
│   ├── main.py              # FastAPI app con Swagger automático
│   ├── middleware/
│   │   ├── __init__.py
│   │   ├── rate_limiter.py  # Rate limiting middleware
│   │   └── error_handler.py # Global error handling
│   ├── models/
│   │   ├── __init__.py
│   │   ├── schemas.py       # Pydantic models con validación estricta
│   │   └── database.py      # SQLite models con turn y max_turns
│   ├── services/
│   │   ├── __init__.py
│   │   ├── conversation_service.py
│   │   ├── langchain_service.py
│   │   └── retry_service.py # Retry logic para APIs externas
│   ├── chains/
│   │   ├── __init__.py
│   │   ├── topic_analysis.py
│   │   ├── position_assignment.py
│   │   ├── persuasive_response.py
│   │   └── consistency_validation.py
│   ├── utils/
│   │   ├── __init__.py
│   │   ├── validators.py    # Validadores personalizados
│   │   └── fallbacks.py     # Respuestas de fallback
│   └── config.py
├── tests/
│   ├── __init__.py
│   ├── test_api.py
│   ├── test_chains.py
│   └── test_database.py
├── postman/
│   └── collection.json      # Postman collection para testing
├── Dockerfile
├── docker-compose.yml
├── Makefile
├── requirements.txt
├── README.md
└── .env.example
```

## Variables de Entorno

```bash
# API Keys
OPENAI_API_KEY=your_openai_api_key_here

# Database
DATABASE_URL=sqlite:///./conversations.db

# Service URLs
OPENAI_BASE_URL=https://api.openai.com/v1
POSTMAN_COLLECTION_URL=[PLACEHOLDER_POSTMAN_URL]
SWAGGER_DOCS_URL=https://api.example.com/docs

# Performance & Limits
MAX_RESPONSE_TIME=30
MAX_MESSAGE_LENGTH=5000
RATE_LIMIT_PER_MINUTE=100

# Retry Configuration
MAX_RETRIES=3
RETRY_DELAY_SECONDS=1
OPENAI_TIMEOUT_SECONDS=25

# Logging
LOG_LEVEL=INFO
```

## Comandos Makefile

```makefile
# Mostrar ayuda
make

# Instalar dependencias
make install

# Ejecutar tests
make test

# Ejecutar servicio en Docker
make run

# Detener servicios
make down

# Limpiar contenedores
make clean
```

## Criterios de Éxito

1. **Funcionalidad**: API responde correctamente según interface especificada
2. **Persuasión**: Bot mantiene posición y argumenta de manera convincente
3. **Coherencia**: Respuestas consistentes a través de la conversación
4. **Performance**: Respuestas en menos de 30 segundos
5. **Durabilidad**: Conversaciones de al menos 5 mensajes
6. **Arquitectura**: Código limpio, bien estructurado y documentado

## Orden de Implementación Detallado

### Fase 1: Fundación (Crítico - Hacer Primero)
**1.1 Configurar estructura del proyecto**
- Crear estructura de carpetas según el plan
- Configurar `requirements.txt` con dependencias base
- Crear `.env.example` con todas las variables
- Configurar `config.py` para manejo de variables de entorno

**1.2 Implementar modelos de base de datos**
- Crear `database.py` con tablas conversations y messages
- Incluir columnas `turn` y `max_turns`
- Implementar funciones básicas de CRUD
- Crear script de inicialización de BD

**1.3 Crear schemas de Pydantic**
- Definir `ChatRequest` con validación estricta (solo 2 atributos)
- Definir `ChatResponse` con messages y conversation_history
- Implementar validadores personalizados (longitud máxima 5000 chars)
- Crear schemas de error responses

### Fase 2: Core Logic (Hacer Segundo)
**2.1 Implementar chains básicas de LangChain**
- `TopicAnalysisChain` - análisis de primer mensaje
- `PositionAssignmentChain` - asignación de posición controversial
- `PersuasiveResponseChain` - generación de respuestas
- `ConsistencyValidationChain` - validación de coherencia

**2.2 Crear retry service y error handling**
- `retry_service.py` con lógica de reintentos para OpenAI
- Manejo específico de errores (RateLimit, Timeout, Auth)
- `fallbacks.py` con respuestas de emergencia
- `validators.py` para validación de respuestas del bot

**2.3 Implementar conversation service**
- Lógica de creación de nuevas conversaciones
- Manejo de turnos y actualización de max_turns
- Recuperación de historial completo
- Integración con chains de LangChain

### Fase 3: API y Middleware (Hacer Tercero)
**3.1 Crear middleware de seguridad**
- `rate_limiter.py` - 100 requests por minuto por IP
- `error_handler.py` - manejo global de excepciones
- Integración con FastAPI middleware stack

**3.2 Desarrollar API endpoints**
- Endpoint `/chat` con validación estricta
- Endpoint `/health` para health checks
- Endpoint `/docs` (automático con FastAPI)
- Manejo de errores 400, 429, 500

**3.3 Integrar todo el flujo**
- Conectar API → middleware → services → chains → database
- Implementar lógica de primer mensaje vs mensajes subsecuentes
- Asegurar respuesta en formato correcto (messages + conversation_history)

### Fase 4: Testing y Deployment (Hacer Cuarto)
**4.1 Crear tests unitarios**
- Tests de schemas y validaciones
- Tests de chains con mocks de OpenAI
- Tests de rate limiting y error handling
- Tests de integration end-to-end

**4.2 Configurar containerización**
- `Dockerfile` optimizado para producción
- `docker-compose.yml` con volúmenes persistentes
- `Makefile` con todos los comandos requeridos

**4.3 Documentación final**
- `README.md` con instrucciones completas
- Documentar todas las variables de entorno
- Crear Postman collection
- Guía de deployment

### Dependencias Críticas
```
Fase 1.1 → Fase 1.2 → Fase 1.3
         ↓
Fase 2.1 → Fase 2.2 → Fase 2.3
         ↓
Fase 3.1 → Fase 3.2 → Fase 3.3
         ↓
Fase 4.1 → Fase 4.2 → Fase 4.3
```

### Prioridades de Testing Durante Desarrollo
1. **Después de Fase 1**: Probar conexión a BD y validaciones básicas
2. **Después de Fase 2**: Probar chains con mocks, sin API real
3. **Después de Fase 3**: Testing completo de API con rate limiting
4. **Fase 4**: Testing de carga y scenarios de error
