Kopi challenge
You made it this far! Let's see what you got 😉

Create an API for a chatbot that can hold a debate and attempt to convince the other side of its views (regardless of how irrational the point).

You can use any programming language other than Java.

Interface
The API consists of the following interface:

Request
{
    "conversation_id": "text" | null,
    "message": "text"
}
Response
{
    "conversation_id": "text",
    // history of the 5 most recent messages on both sides. most recent message last
    "message": [
        {
            "role": "user",
            "message": "text"
        },
        {
            "role": "bot",
            "message": "text"
        }
    ]
Starting the conversation
The first message sent to your API:

will not include a conversation_id. That's how you'll know to start a new conversation
define the topic of the conversation and what side of the conversation your bot should take
Stand your ground
All of your responses should be related to the original conversation topic and stand your ground.

The goal is to convince the other side of your view, even if that view is the Earth is flat.

Part of the challenge will be maintaining your view and being persuasive (without being overly argumentative) throughout the conversation.

Part of the performance will be judged by persuasiveness and ability to hold a cohesive coversation across multiple messages.

You should be able to respond to at least one message to submit the solution. You should target the conversation exceeding at least five messages. The longer the better.

Max API response should be 30 seconds.

Code structure
You must include a Makefile with at least the following commands:

make: shows a list of all possible make commands
make install: install all requirements to run the service. if some tool is required for the installation, you must detect its absence and provide installation instructions
make test: run tests
make run: run the service and all related services (such as a db) in Docker
make down: teardown of all running services
make clean: teardown and removal of all containers
Your README.md should include instrcuctions on all env vars that need to be set and other information to run the service.

Evaluation
The submission will also be evaluated based on clarity and architectual decisions. Providing an explanation of why you made certain decisions helps our ability to evaluate the solution. Follow the same coding standards you'd follow on a professional project.

Submission
Email Shaili the following:

a public URL of your running API that can be tested
a link to a compressed tarball of your git repo (include the commit history)